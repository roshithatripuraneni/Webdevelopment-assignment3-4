'''
Create an Account class that mimics the account table
'''
import typing as t
from unicodedata import decimal

class Account():
    def init(self, investor_id: int, balance: float, account_type: str, id: int = -1):
        self.id = id
        self.investor_id = investor_id
        self.balance = balance
        self.account_type = account_type

    def str(self): 
        return f'[id: {self.id}, investor_id: {self.investor.id}, balance: {self.balance}, account_type: {self.account_type}]'

    @staticmethod
    def from_dict(dict):
        if dict.get('account_number') is None or dict.get('investor_id') is None or dict.get('balance') is None: # all attributes are required
            raise Exception(f'Can not create account object from dict {dict}: missing required attributes')
        else:
            return Account(dict.get('account_number'), dict.get('investor_id'), dict.get('balance'))