'''
Create CRUD functions for the portfolio data table. Example: get_portfolio_by_id
'''
import typing as t
from mysql.connector import MySQLConnection
from .dbutils import get_db_cnx
from app.src.domain.Portfolio import Portfolio, portfolio
import app.src.dao.sql as sql


def get_portfolio_by_id(id: int) -> t.Optional[portfolio]:
    try:
        db_cnx: MySQLConnection = get_db_cnx()
        cursor = db_cnx.cursor(dictionary=True)
        cursor.execute(sql.portfolio_by_id, (id,))
        rs = cursor.fetchone()
        if rs is None:
            return None
        return portfolio(rs['account_id'], rs['ticker'], rs['quantity'],rs['invested_amount'], rs['id'])
    except Exception as e:
        print(f'Unable to retrieve portfolio by Id {id}: {str(e)}')
    finally:
        cursor.close()
        db_cnx.close()

def get_all_portfolio() -> t.List[Portfolio]: # empty list if no investors are created in the db
    try:
        db_cnx: MySQLConnection = get_db_cnx()
        cursor = db_cnx.cursor(dictionary=True) # results will return as a dict
        cursor.execute(sql.get_all_account_sql)
        rs = cursor.fetchall()
        if len(rs) == 0:
            return []
        else:
            portfolio = []
            for row in rs:
                portfolio.append(Portfolio(row.get('name'), row.get('address'), row.get('status'), row.get('id')))
            return portfolio
    except Exception as e:
        print(f'An exception occurred while trying to get a list of all portfolios: {str(e)}')
    finally:
        cursor.close()
        db_cnx.close()
        

def get_portfolio_by_account_id(id: int) -> t.List[portfolio]:
    try:
        db_cnx: MySQLConnection = get_db_cnx()
        cursor = db_cnx.cursor(dictionary=True)
        cursor.execute(sql.get_portfolio_by_account_id_sql, (id, ))
        rs = cursor.fetchall()
        if len(rs) == 0:
            return []
        else:
            portfolio = []
            for row in rs:
                portfolio.append(portfolio(row['account_id'], row['ticker'], row['quantity'], row['invested_amount'], row['id']))
        return portfolio
    except Exception as e:
        print(f'Unable to retrieve portfolio named {id}: {int(e)}')
    finally:
        cursor.close()
        db_cnx.close()

def create_portfolio(portfolio: portfolio) -> None:
    try:
        db_cnx: MySQLConnection = get_db_cnx()
        cursor = db_cnx.cursor()
        cursor.execute(sql.create_portfolio, (portfolio.account_id, portfolio.ticker, portfolio.quantity, portfolio.invested_amount))
        db_cnx.commit()
    except Exception as e:
        print(f'Unable to create a new portfolio: {str(e)}')
    finally:
        cursor.close()
        db_cnx.close()

def update_portfolio_account_id(id: int, account_id: str) -> None:
    try:
        db_cnx: MySQLConnection = get_db_cnx()
        cursor = db_cnx.cursor()
        cursor.execute(sql.update_portfoli_account_id, (account_id, id))
        db_cnx.commit()
    except Exception as e:
        print(f'Unable to update portfolio account id: {str(e)}')
    finally: 
        cursor.close()
        db_cnx.close()

def update_portfolio_address(id: int, address: str) -> None:
    try:
        db_cnx = get_db_cnx()
        cursor = db_cnx.cursor()
        cursor.execute(sql.update_portfolio_address_sql, (address, id))
        db_cnx.commit()
    except Exception as e:
        print(f'Unable to update portfolio address: str(e)')
    finally:
        cursor.close()
        db_cnx.close()

def update_portfolio_ticker(id: int, ticker: str) -> t.Optional[portfolio]:
    try:
        db_cnx: MySQLConnection = get_db_cnx()
        cursor = db_cnx.cursor()
        cursor.execute(sql.update_portfolio_name, (ticker, id))
        db_cnx.commit()
    except Exception as e:
        print(f'Unable to update portfolio ticker: {str(e)}')
    finally: 
        cursor.close()
        db_cnx.close()

def update_portfolio_quantity(id: int, quantity: str) -> t.Optional[portfolio]:
    try:
        db_cnx: MySQLConnection = get_db_cnx()
        cursor = db_cnx.cursor()
        cursor.execute(sql.update_portfolio_name, (quantity, id))
        db_cnx.commit()
    except Exception as e:
        print(f'Unable to update portfolio quantity: {str(e)}')
    finally: 
        cursor.close()
        db_cnx.close()        

def update_portfolio_invested_amount(id: int, invested_amount: int) -> int[portfolio]:
    try:
        db_cnx: MySQLConnection = get_db_cnx()
        cursor = db_cnx.cursor()
        cursor.execute(sql.update_portfolio_invested_amount, (invested_amount, id))
        db_cnx.commit()
    except Exception as e:
        print(f'Unable to update portfolio invested_amount: {int(e)}')
    finally: 
        cursor.close()
        db_cnx.close()

def delete_portfolio_by_id(id: int) -> None: 
    try:
        db_cnx = get_db_cnx()
        cursor = db_cnx.cursor()
        cursor.execute(sql.delete_portfolio_by_id, (id,))
        db_cnx.commit()
    except Exception as e:
        print(f'Unable to delete portfolio: str(e)')
    finally:
        cursor.close()
        db_cnx.close()


def buy_stock(ticker: str, price: float, quantity: int,account_number: int) -> None:
    ''' 
        portfolio - p
        account - a
        for an investor acct, two cases:
            buy the same stocks(update: quantity(p), balance(a))
        OR buy different kinds of stocks- insert new records: ticker(p), purchase_price(p), quantity(p), and update balance(a)      
        
    '''
    #get current balance
    db_cnx: MySQLConnection = get_db_cnx()
    cursor = db_cnx.cursor(dictionary=True) # always pass dictionary = True
    sql: str = 'select * from portfolio where account_number= %s and ticker = %s;'
    cursor.execute(sql)
    result_bal = cursor.fetchone()
    current_balance = result_bal[2]
    db_cnx.close()

    #calculate and update account balance
    db_cnx: MySQLConnection = get_db_cnx()
    db_cnx = get_db_cnx()
    cursor = db_cnx.cursor()
    balance_updated = current_balance - price * quantity
    if balance_updated <= 0:
        print('No balance left.')
        return None
    cursor.execute('update account set balance = %s where account_number = %s;', balance_updated, account_number)
    db_cnx.commit()
    db_cnx.close()

    #insert into new portfolio records
    db_cnx = get_db_cnx()
    cursor = db_cnx.cursor()
    cursor.execute('select * from portfolio where account_number = %s and ticker = %s;',account_number,ticker)
    row = cursor.fetchone()
    if row == 0:
        db_cnx = get_db_cnx()
        cursor = db_cnx.cursor()
        cursor.execute('insert into portfolio (account_number, ticker, quantity, purchase_price) values (%s, "%s", %s, %s)')        
        db_cnx.commit()
        db_cnx.close()
    else: #update stock quantity 
        quantity_increment = row[2]
        quantity_updated = quantity + quantity_increment
        db_cnx = get_db_cnx()
        cursor = db_cnx.cursor()
        cursor.execute('update portfolio set quantity= %s where account_number = %s and ticker = %s;', quantity_updated,account_number,ticker)
        db_cnx.commit()
        db_cnx.close()

        

def sell_stock(ticker: str, quantity: int, sale_price: float, account_number:int) -> None:
    # 1. update quantity in portfolio table
    # 2. update the account balance:
    # Example: 10 APPL shares at $1/share with account balance $100, here purchase_price = 1
    # event: sale of 2 shares for $2/share
    # output: 8 APPLE shares at $1/share with account balance = 100 + 2 * (12 - 10) = $104
    
    #get stock quantity from portfolio  
    db_cnx: MySQLConnection = get_db_cnx()
    cursor = db_cnx.cursor(dictionary=True) # always pass dictionary = True
    cursor.execute('select * from portfolio where account_number = %s and ticker = %s;', account_number, ticker)
    row = cursor.fetchone()
    if row == 0:
        return None
    else:
        quantity_current = row['quantity']
    db_cnx.close()
    
    #get current balance and calculate balance affected
    db_cnx = get_db_cnx()
    cursor = db_cnx.cursor()
    cursor.execute('select * from account where account_number =%s;', account_number) 
    row_bal = cursor.fetchone()
    current_balance = row_bal[2]
    balance_new = current_balance + quantity * sale_price
    db_cnx.close()
       
    #update portfolio table: new quantity after selling stocks(given account number and ticker)
    db_cnx = get_db_cnx()
    cursor = db_cnx.cursor()
    quantity_new = quantity_current - quantity 
    cursor.execute('update portfolio set quantity= %s where account_number = %s and ticker = %s;', (quantity_new,account_number,ticker))
    db_cnx.commit()

    #update account table: new balance (given account number)
    db_cnx = get_db_cnx()
    cursor = db_cnx.cursor()
    cursor.execute('update account set balance = %s where account_number = %s;',balance_new,account_number)
    db_cnx.commit()
    db_cnx.close()