db_config = {
    'host': 'east-2.rds.amazonaws.com',
    'port': 3306,
    'user': 'admin',
    'password': 'roshithaB2',
    'db': 'rxttradetrade'
}